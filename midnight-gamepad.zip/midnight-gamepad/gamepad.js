/** Midnight Gamepad – dependency-free Web Component. MIT License. */
class MidnightGamepad extends HTMLElement {
  static get observedAttributes() { return ['opacity', 'size', 'buttons', 'stick']; }
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
    this.state = { x: 0, y: 0, A: false, B: false, X: false, Y: false };
    this._stickPointer = null;
    this._buttonPointers = new Map();
    this._pressedKeys = new Set();
    this._useKeyboard = false;
    this._keydown = e => this._handleKey(e, true);
    this._keyup = e => this._handleKey(e, false);
    this._blur = () => this.reset();
    this._visibility = () => { if (document.hidden) this.reset(); };
  }

  connectedCallback() {
    if (!this.shadowRoot.querySelector('.pad')) {
      this._render();
      this._bindControls();
    }
    this._useKeyboard = this.hasAttribute('keyboard');
    if (this._useKeyboard) {
      window.addEventListener('keydown', this._keydown);
      window.addEventListener('keyup', this._keyup);
    }
    window.addEventListener('blur', this._blur);
    document.addEventListener('visibilitychange', this._visibility);
  }

  disconnectedCallback() {
    window.removeEventListener('keydown', this._keydown);
    window.removeEventListener('keyup', this._keyup);
    window.removeEventListener('blur', this._blur);
    document.removeEventListener('visibilitychange', this._visibility);
    this.reset();
  }

  attributeChangedCallback(name) {
    if (name === 'opacity' || name === 'size' || name === 'stick') this._applyOptions();
    if (name === 'buttons') this._updateButtonVisibility();
  }

  get x() { return this.state.x; }
  get y() { return this.state.y; }
  get A() { return this.state.A; }
  get B() { return this.state.B; }
  get X() { return this.state.X; }
  get Y() { return this.state.Y; }
  get axes() { return { x: this.x, y: this.y }; }
  get buttons() { return { A: this.A, B: this.B, X: this.X, Y: this.Y }; }

  reset() {
    this._stickPointer = null;
    this._buttonPointers.clear();
    this._pressedKeys.clear();
    this._setAxis(0, 0);
    for (const key of ['A','B','X','Y']) this._setButton(key, false);
  }

  _render() {
    this.shadowRoot.innerHTML = `
      <style>
        :host { --mg-size: 120px; --mg-opacity: .85; display: block; position: absolute;
          inset: 0; z-index: 10; pointer-events: none; font-family: system-ui, sans-serif;
          user-select: none; -webkit-user-select: none; -webkit-tap-highlight-color: transparent; }
        .pad { position: absolute; inset: 0; opacity: var(--mg-opacity); pointer-events: none; }
        .stick { position: absolute; left: max(18px, env(safe-area-inset-left)); bottom: 12%;
          width: var(--mg-size); height: var(--mg-size); border-radius: 50%; box-sizing: border-box;
          background: #ffffff24; border: 2px solid #ffffff73; touch-action: none;
          pointer-events: auto; }
        .knob { position: absolute; left: 50%; top: 50%; width: 46%; height: 46%;
          border-radius: 50%; background: #67b7ff; border: 2px solid #d0eaff;
          transform: translate(-50%, -50%); pointer-events: none; box-sizing: border-box; }
        .buttons { position: absolute; right: max(18px, env(safe-area-inset-right)); bottom: 9%;
          display: grid; grid-template-columns: repeat(3, calc(var(--mg-size) * .4));
          grid-template-rows: repeat(3, calc(var(--mg-size) * .4)); gap: 3px;
          pointer-events: none; }
        button { border: 0; border-radius: 50%; width: 100%; height: 100%;
          color: #fff; font-size: calc(var(--mg-size) * .13); font-weight: 800;
          touch-action: none; pointer-events: auto; user-select: none; cursor: pointer;
          -webkit-tap-highlight-color: transparent; }
        button.active { filter: brightness(1.5); transform: scale(.94); }
        [data-button=Y] { grid-column: 2; grid-row: 1; background: #e6a532; }
        [data-button=X] { grid-column: 1; grid-row: 2; background: #397fd4; }
        [data-button=B] { grid-column: 3; grid-row: 2; background: #d84b66; }
        [data-button=A] { grid-column: 2; grid-row: 3; background: #39a67b; }
        :host([stick="right"]) .stick { left: auto; right: max(18px, env(safe-area-inset-right)); }
        :host([stick="right"]) .buttons { right: auto; left: max(18px, env(safe-area-inset-left)); }
        :host([hidden]) { display: none; }
      </style>
      <div class="pad">
        <div class="stick" role="group" aria-label="Virtueller Analogstick"><div class="knob"></div></div>
        <div class="buttons" role="group" aria-label="Aktionstasten">
          <button type="button" data-button="Y" aria-label="Taste Y">Y</button>
          <button type="button" data-button="X" aria-label="Taste X">X</button>
          <button type="button" data-button="B" aria-label="Taste B">B</button>
          <button type="button" data-button="A" aria-label="Taste A">A</button>
        </div>
      </div>`;
    this._applyOptions();
    this._updateButtonVisibility();
  }

  _applyOptions() {
    const opacity = Math.min(1, Math.max(0.1, Number(this.getAttribute('opacity') ?? .85) || .85));
    const size = Math.min(240, Math.max(80, Number(this.getAttribute('size') ?? 120) || 120));
    this.style.setProperty('--mg-opacity', String(opacity));
    this.style.setProperty('--mg-size', `${size}px`);
  }

  _updateButtonVisibility() {
    if (!this.shadowRoot.querySelector('.buttons')) return;
    const count = Math.min(4, Math.max(0, Number(this.getAttribute('buttons') ?? 4)));
    for (const [i, key] of ['A', 'B', 'X', 'Y'].entries()) {
      const btn = this.shadowRoot.querySelector(`[data-button="${key}"]`);
      btn.hidden = i >= count;
      if (i >= count) this._setButton(key, false);
    }
  }

  _bindControls() {
    const stick = this.shadowRoot.querySelector('.stick');
    stick.addEventListener('pointerdown', e => {
      if (this._stickPointer !== null) return;
      e.preventDefault();
      this._stickPointer = e.pointerId;
      stick.setPointerCapture(e.pointerId);
      this._moveStick(e);
    });
    stick.addEventListener('pointermove', e => {
      if (e.pointerId === this._stickPointer) this._moveStick(e);
    });
    const endStick = e => {
      if (e.pointerId !== this._stickPointer) return;
      this._stickPointer = null;
      this._setAxis(0, 0);
    };
    for (const event of ['pointerup', 'pointercancel', 'lostpointercapture'])
      stick.addEventListener(event, endStick);

    for (const btn of this.shadowRoot.querySelectorAll('button')) {
      const name = btn.dataset.button;
      btn.addEventListener('pointerdown', e => {
        if (this._buttonPointers.has(name)) return;
        e.preventDefault();
        this._buttonPointers.set(name, e.pointerId);
        btn.setPointerCapture(e.pointerId);
        this._setButton(name, true);
      });
      const end = e => {
        if (this._buttonPointers.get(name) !== e.pointerId) return;
        this._buttonPointers.delete(name);
        this._setButton(name, false);
      };
      for (const event of ['pointerup', 'pointercancel', 'lostpointercapture'])
        btn.addEventListener(event, end);
    }
  }

  _moveStick(e) {
    const rect = this.shadowRoot.querySelector('.stick').getBoundingClientRect();
    const maxDistance = rect.width * .34;
    let dx = e.clientX - (rect.left + rect.width / 2);
    let dy = e.clientY - (rect.top + rect.height / 2);
    const len = Math.hypot(dx, dy);
    if (len > maxDistance) { dx *= maxDistance / len; dy *= maxDistance / len; }
    this._setAxis(dx / maxDistance, dy / maxDistance);
  }

  _setAxis(x, y) {
    if (this.state.x === x && this.state.y === y) return;
    this.state.x = x;
    this.state.y = y;
    const knob = this.shadowRoot.querySelector('.knob');
    if (knob) {
      const size = this.shadowRoot.querySelector('.stick').getBoundingClientRect().width;
      knob.style.left = `calc(50% + ${x * size * .34}px)`;
      knob.style.top = `calc(50% + ${y * size * .34}px)`;
    }
    this.dispatchEvent(new CustomEvent('gamepadmove', { detail: this.axes, bubbles: true }));
  }

  _setButton(name, pressed) {
    if (this.state[name] === pressed) return;
    this.state[name] = pressed;
    const btn = this.shadowRoot.querySelector(`[data-button="${name}"]`);
    if (btn) btn.classList.toggle('active', pressed);
    this.dispatchEvent(new CustomEvent('gamepadbutton', {
      detail: { button: name, pressed }, bubbles: true
    }));
  }

  _handleKey(e, down) {
    const key = e.key.toLowerCase();
    const relevant = ['arrowleft','arrowright','arrowup','arrowdown','w','a','s','d','j','k','u','i',' '];
    if (!relevant.includes(key)) return;
    if (['input','textarea','select'].includes(document.activeElement?.tagName?.toLowerCase()) || document.activeElement?.isContentEditable) return;
    e.preventDefault();
    if (down) this._pressedKeys.add(key); else this._pressedKeys.delete(key);
    const has = (...keys) => keys.some(k => this._pressedKeys.has(k));
    let x = Number(has('arrowright','d')) - Number(has('arrowleft','a'));
    let y = Number(has('arrowdown','s')) - Number(has('arrowup','w'));
    const mag = Math.hypot(x,y);
    if (mag > 1) { x /= mag; y /= mag; }
    if (this._stickPointer === null) this._setAxis(x,y);
    for (const [button, keys] of Object.entries({ A:[' ','j'], B:['k'], X:['u'], Y:['i'] })) {
      if (!this._buttonPointers.has(button)) this._setButton(button, has(...keys));
    }
  }
}

if (!customElements.get('midnight-gamepad')) customElements.define('midnight-gamepad', MidnightGamepad);
