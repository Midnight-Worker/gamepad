const canvas = document.querySelector('#screen');
const ctx = canvas.getContext('2d');
const pad = document.querySelector('midnight-gamepad');
const hud = document.querySelector('#hud');
let width = 1, height = 1;
const ball = { x: 0, y: 0, vx: 0, vy: 0, radius: 12, color: '#50e0ff' };
const ACCELERATION = 900;
const FRICTION = 6;
const MAX_SPEED = 350;

function resize() {
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  width = canvas.clientWidth;
  height = canvas.clientHeight;
  canvas.width = Math.round(width * dpr);
  canvas.height = Math.round(height * dpr);
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ball.x = Math.max(ball.radius, Math.min(width - ball.radius, ball.x));
  ball.y = Math.max(ball.radius, Math.min(height - ball.radius, ball.y));
}
window.addEventListener('resize', resize);
resize();
ball.x = width / 2;
ball.y = height / 2;

pad.addEventListener('gamepadbutton', e => {
  if (!e.detail.pressed) return;
  switch (e.detail.button) {
    case 'A': ball.vx *= 1.6; ball.vy *= 1.6; break;
    case 'B': ball.vx = ball.vy = 0; break;
    case 'X': ball.color = `hsl(${Math.floor(Math.random() * 360)} 90% 60%)`; break;
    case 'Y': ball.x = width/2; ball.y = height/2; ball.vx = ball.vy = 0; break;
  }
});

function update(dt) {
  ball.vx += pad.x * ACCELERATION * dt;
  ball.vy += pad.y * ACCELERATION * dt;
  const friction = Math.exp(-FRICTION * dt);
  ball.vx *= friction;
  ball.vy *= friction;
  let speed = Math.hypot(ball.vx, ball.vy);
  if (speed > MAX_SPEED) {
    ball.vx *= MAX_SPEED / speed;
    ball.vy *= MAX_SPEED / speed;
  }
  if (Math.abs(ball.vx) < .5) ball.vx = 0;
  if (Math.abs(ball.vy) < .5) ball.vy = 0;
  ball.x += ball.vx * dt;
  ball.y += ball.vy * dt;
  if (ball.x < ball.radius) { ball.x = ball.radius; ball.vx = 0; }
  if (ball.x > width - ball.radius) { ball.x = width - ball.radius; ball.vx = 0; }
  if (ball.y < ball.radius) { ball.y = ball.radius; ball.vy = 0; }
  if (ball.y > height - ball.radius) { ball.y = height - ball.radius; ball.vy = 0; }
}
function draw() {
  ctx.fillStyle = '#101827';
  ctx.fillRect(0, 0, width, height);
  ctx.strokeStyle = '#223047';
  for (let x = 0; x < width; x += 40) { ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,height); ctx.stroke(); }
  for (let y = 0; y < height; y += 40) { ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(width,y); ctx.stroke(); }
  ctx.fillStyle = ball.color;
  ctx.beginPath(); ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI*2); ctx.fill();
  hud.textContent = `MIDNIGHT GAMEPAD · x:${ball.x.toFixed(0)} y:${ball.y.toFixed(0)} · v:${Math.hypot(ball.vx,ball.vy).toFixed(0)}`;
}
let last = 0;
function frame(t) {
  const dt = last ? Math.min((t-last)/1000, .05) : 0;
  last = t;
  update(dt);
  draw();
  requestAnimationFrame(frame);
}
document.addEventListener('visibilitychange', () => { last = 0; });
requestAnimationFrame(frame);
